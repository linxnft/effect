/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      animation: {
        'wave-1': 'wave1 20s infinite',
        'wave-2': 'wave2 15s infinite',
        'wave-3': 'wave3 10s infinite',
      },
    },
  },
  plugins: [],
};