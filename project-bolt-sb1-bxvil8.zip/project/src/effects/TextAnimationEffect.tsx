import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';

export const TextAnimationEffect = () => {
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const chars = textRef.current?.querySelectorAll('.char');
    
    gsap.from(chars, {
      opacity: 0,
      y: 100,
      rotateX: -90,
      stagger: 0.02,
      duration: 1,
      ease: 'back.out',
      repeat: -1,
      repeatDelay: 3
    });
  }, []);

  const text = 'Animation Magic';
  
  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center">
      <div ref={textRef} className="text-6xl font-bold">
        {text.split('').map((char, index) => (
          <span
            key={index}
            className="char inline-block text-transparent bg-clip-text bg-gradient-to-r 
              from-indigo-600 to-purple-600"
          >
            {char}
          </span>
        ))}
      </div>
    </div>
  );
};