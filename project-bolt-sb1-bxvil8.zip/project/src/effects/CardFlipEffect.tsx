import React, { useState } from 'react';
import { motion } from 'framer-motion';

export const CardFlipEffect = () => {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center perspective-1000">
      <div
        className="w-64 h-96 relative preserve-3d cursor-pointer"
        onClick={() => setIsFlipped(!isFlipped)}
      >
        <motion.div
          initial={false}
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
          className="absolute inset-0 backface-hidden"
        >
          <div className="w-full h-full bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl p-6 flex items-center justify-center">
            <h3 className="text-2xl font-bold text-white">Front</h3>
          </div>
        </motion.div>
        <motion.div
          initial={false}
          animate={{ rotateY: isFlipped ? 0 : -180 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
          className="absolute inset-0 backface-hidden"
        >
          <div className="w-full h-full bg-gradient-to-br from-purple-600 to-pink-600 rounded-xl p-6 flex items-center justify-center">
            <h3 className="text-2xl font-bold text-white">Back</h3>
          </div>
        </motion.div>
      </div>
    </div>
  );
};