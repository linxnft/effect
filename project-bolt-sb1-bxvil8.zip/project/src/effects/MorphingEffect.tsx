import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';

export const MorphingEffect = () => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const shapes = [
      "M100,100 C100,0 400,0 400,100 C400,200 100,200 100,100",
      "M100,100 C150,50 350,50 400,100 C350,150 150,150 100,100",
      "M250,50 C350,50 350,150 250,150 C150,150 150,50 250,50"
    ];

    let currentShape = 0;

    const morphAnimation = () => {
      currentShape = (currentShape + 1) % shapes.length;
      gsap.to("path", {
        duration: 1,
        attr: { d: shapes[currentShape] },
        ease: "power2.inOut"
      });
    };

    const interval = setInterval(morphAnimation, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-screen flex items-center justify-center bg-gray-900">
      <svg ref={svgRef} width="500" height="200" viewBox="0 0 500 200">
        <path
          d="M100,100 C100,0 400,0 400,100 C400,200 100,200 100,100"
          fill="none"
          stroke="url(#gradient)"
          strokeWidth="4"
        />
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#4F46E5" />
            <stop offset="100%" stopColor="#9333EA" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};