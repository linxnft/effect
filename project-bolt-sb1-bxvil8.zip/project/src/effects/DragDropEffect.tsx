import React, { useState } from 'react';
import { motion, Reorder } from 'framer-motion';

const initialImages = [
  'https://images.unsplash.com/photo-1558655146-9f40138edfeb',
  'https://images.unsplash.com/photo-1558655147-59f4b3996139',
  'https://images.unsplash.com/photo-1558655148-7a0e37dfe964',
  'https://images.unsplash.com/photo-1558655149-582f62d4939c'
];

export const DragDropEffect = () => {
  const [images, setImages] = useState(initialImages);

  return (
    <div className="min-h-screen bg-gray-900 p-8 flex items-center justify-center">
      <Reorder.Group
        axis="y"
        values={images}
        onReorder={setImages}
        className="space-y-4 w-full max-w-2xl"
      >
        {images.map((image) => (
          <Reorder.Item
            key={image}
            value={image}
            className="w-full cursor-grab active:cursor-grabbing"
          >
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full aspect-video rounded-lg overflow-hidden"
            >
              <img
                src={image}
                alt="Draggable item"
                className="w-full h-full object-cover"
              />
            </motion.div>
          </Reorder.Item>
        ))}
      </Reorder.Group>
    </div>
  );
};