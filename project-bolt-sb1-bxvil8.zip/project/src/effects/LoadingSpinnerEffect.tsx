import React from 'react';

export const LoadingSpinnerEffect = () => {
  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center">
      <div className="relative w-24 h-24">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className={`absolute inset-0 border-4 border-transparent 
              border-t-indigo-600 rounded-full animate-spin`}
            style={{
              animationDuration: `${1 + i * 0.2}s`,
              animationDelay: `${i * 0.1}s`
            }}
          />
        ))}
      </div>
    </div>
  );
};