import React from 'react';

export const NeonPulse = () => {
  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center">
      <style>{`
        .neon-text {
          color: #fff;
          text-shadow: 
            0 0 7px #fff,
            0 0 10px #fff,
            0 0 21px #fff,
            0 0 42px #4F46E5,
            0 0 82px #4F46E5,
            0 0 92px #4F46E5,
            0 0 102px #4F46E5,
            0 0 151px #4F46E5;
          animation: neon-pulse 1.5s ease-in-out infinite alternate;
        }

        @keyframes neon-pulse {
          from {
            text-shadow: 
              0 0 7px #fff,
              0 0 10px #fff,
              0 0 21px #fff,
              0 0 42px #4F46E5,
              0 0 82px #4F46E5,
              0 0 92px #4F46E5,
              0 0 102px #4F46E5,
              0 0 151px #4F46E5;
          }
          to {
            text-shadow: 
              0 0 4px #fff,
              0 0 7px #fff,
              0 0 14px #fff,
              0 0 32px #7C3AED,
              0 0 62px #7C3AED,
              0 0 72px #7C3AED,
              0 0 82px #7C3AED,
              0 0 121px #7C3AED;
          }
        }

        .neon-box {
          position: relative;
          padding: 4rem;
        }

        .neon-box::before {
          content: '';
          position: absolute;
          inset: 0;
          border: 4px solid transparent;
          border-radius: 1rem;
          background: linear-gradient(45deg, #4F46E5, #7C3AED) border-box;
          -webkit-mask: 
            linear-gradient(#fff 0 0) padding-box,
            linear-gradient(#fff 0 0);
          -webkit-mask-composite: destination-out;
          mask-composite: exclude;
          animation: neon-border-pulse 1.5s ease-in-out infinite alternate;
        }

        @keyframes neon-border-pulse {
          from {
            filter: drop-shadow(0 0 2px #4F46E5) 
                    drop-shadow(0 0 4px #4F46E5)
                    drop-shadow(0 0 6px #4F46E5);
          }
          to {
            filter: drop-shadow(0 0 4px #7C3AED)
                    drop-shadow(0 0 8px #7C3AED)
                    drop-shadow(0 0 12px #7C3AED);
          }
        }
      `}</style>
      <div className="neon-box">
        <h2 className="neon-text text-6xl font-bold">NEON</h2>
      </div>
    </div>
  );
};