import React from 'react';
import { motion } from 'framer-motion';

const cards = [
  {
    id: 1,
    title: 'Floating Card 1',
    color: 'from-indigo-500 to-purple-500'
  },
  {
    id: 2,
    title: 'Floating Card 2',
    color: 'from-blue-500 to-indigo-500'
  },
  {
    id: 3,
    title: 'Floating Card 3',
    color: 'from-purple-500 to-pink-500'
  }
];

export const FloatingCards = () => {
  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center">
      <div className="relative w-[600px] h-[400px]">
        {cards.map((card, index) => (
          <motion.div
            key={card.id}
            className={`absolute w-64 h-64 rounded-2xl bg-gradient-to-br ${card.color} p-6
              shadow-xl cursor-pointer`}
            style={{
              top: `${index * 40}px`,
              left: `${index * 40}px`,
            }}
            drag
            dragConstraints={{
              top: -100,
              left: -100,
              right: 100,
              bottom: 100,
            }}
            dragElastic={0.7}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            animate={{
              y: [0, -10, 0],
              rotate: [0, 2, -2, 0],
            }}
            transition={{
              y: {
                duration: 2.5,
                repeat: Infinity,
                repeatType: "reverse",
                ease: "easeInOut",
                delay: index * 0.2,
              },
              rotate: {
                duration: 4,
                repeat: Infinity,
                repeatType: "reverse",
                ease: "easeInOut",
                delay: index * 0.2,
              },
            }}
          >
            <h3 className="text-xl font-bold text-white">{card.title}</h3>
            <p className="text-white/80 mt-2">Drag me around!</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};