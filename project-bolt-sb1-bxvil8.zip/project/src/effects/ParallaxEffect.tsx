import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

export const ParallaxEffect = () => {
  const { scrollYProgress } = useScroll();
  
  const y1 = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const y3 = useTransform(scrollYProgress, [0, 1], [0, -300]);

  return (
    <div className="h-[200vh] relative">
      <div className="sticky top-0 h-screen overflow-hidden">
        <motion.div 
          style={{ y: y1 }}
          className="absolute inset-0"
        >
          <img 
            src="https://images.unsplash.com/photo-1579546929518-9e396f3cc809" 
            alt="Background"
            className="w-full h-full object-cover"
          />
        </motion.div>
        <motion.div 
          style={{ y: y2 }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <div className="text-6xl font-bold text-white text-center">
            Parallax Effect
          </div>
        </motion.div>
        <motion.div 
          style={{ y: y3 }}
          className="absolute inset-0 flex items-end justify-center pb-20"
        >
          <div className="text-2xl text-white text-center">
            Scroll to see the magic
          </div>
        </motion.div>
      </div>
    </div>
  );
};