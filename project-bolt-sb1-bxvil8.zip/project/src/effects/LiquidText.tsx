import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';

export const LiquidText = () => {
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!textRef.current) return;

    const chars = textRef.current.querySelectorAll('.char');
    const timeline = gsap.timeline({ repeat: -1 });

    chars.forEach((char, i) => {
      timeline.to(char, {
        y: 'random(-20, 20)',
        scaleY: 'random(0.8, 1.2)',
        scaleX: 'random(0.9, 1.1)',
        duration: 0.6,
        ease: 'power2.inOut',
      }, i * 0.02);
    });

    timeline.to(chars, {
      y: 0,
      scaleY: 1,
      scaleX: 1,
      duration: 0.6,
      ease: 'power2.inOut',
    });

    return () => timeline.kill();
  }, []);

  const text = 'Liquid Text';

  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center">
      <div
        ref={textRef}
        className="text-6xl font-bold bg-gradient-to-r from-indigo-500 to-purple-500 
          bg-clip-text text-transparent"
      >
        {text.split('').map((char, i) => (
          <span
            key={i}
            className="char inline-block"
            style={{ transformOrigin: 'center bottom' }}
          >
            {char}
          </span>
        ))}
      </div>
    </div>
  );
};