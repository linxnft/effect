import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import ScrollTrigger from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const ScrollTriggerEffect = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const elements = containerRef.current?.querySelectorAll('.animate-item');
    
    elements?.forEach((element) => {
      gsap.from(element, {
        scrollTrigger: {
          trigger: element,
          start: 'top center+=100',
          toggleActions: 'play none none reverse'
        },
        opacity: 0,
        y: 100,
        duration: 1,
        ease: 'power2.out'
      });
    });
  }, []);

  return (
    <div ref={containerRef} className="min-h-[200vh] bg-gray-900 p-8">
      <div className="max-w-4xl mx-auto space-y-32 py-32">
        {[1, 2, 3, 4].map((item) => (
          <div
            key={item}
            className="animate-item bg-gradient-to-br from-indigo-600 to-purple-600 
              rounded-2xl p-8 text-white"
          >
            <h3 className="text-2xl font-bold mb-4">Scroll Item {item}</h3>
            <p className="text-lg opacity-90">
              This element animates as you scroll into view.
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};