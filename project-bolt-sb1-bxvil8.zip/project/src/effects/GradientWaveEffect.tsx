import React from 'react';

export const GradientWaveEffect = () => {
  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center overflow-hidden">
      <div className="relative w-96 h-96">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 animate-wave-1" />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-indigo-500 animate-wave-2" />
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 animate-wave-3" />
      </div>
    </div>
  );
};