import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const items = [
  {
    id: 1,
    title: 'Mountain',
    image: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679'
  },
  {
    id: 2,
    title: 'Ocean',
    image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b'
  },
  {
    id: 3,
    title: 'Forest',
    image: 'https://images.unsplash.com/photo-1511497584788-876760111969'
  }
];

export const ThreeDCarousel = () => {
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(0);

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
      rotateY: direction > 0 ? 45 : -45,
      scale: 0.8
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      rotateY: 0,
      scale: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
      rotateY: direction < 0 ? 45 : -45,
      scale: 0.8
    })
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  const paginate = (newDirection: number) => {
    setDirection(newDirection);
    setCurrent((current + newDirection + items.length) % items.length);
  };

  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center overflow-hidden perspective-1000">
      <div className="relative w-[600px] h-[400px]">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={current}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 },
              rotateY: { duration: 0.4 }
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={1}
            onDragEnd={(e, { offset, velocity }) => {
              const swipe = swipePower(offset.x, velocity.x);

              if (swipe < -swipeConfidenceThreshold) {
                paginate(1);
              } else if (swipe > swipeConfidenceThreshold) {
                paginate(-1);
              }
            }}
            className="absolute w-full h-full"
          >
            <div className="w-full h-full rounded-2xl overflow-hidden shadow-2xl">
              <img
                src={items[current].image}
                alt={items[current].title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-8">
                <h2 className="text-3xl font-bold text-white">
                  {items[current].title}
                </h2>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
        
        <div className="absolute bottom-[-60px] left-0 right-0 flex justify-center gap-4">
          {items.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                const newDirection = index > current ? 1 : -1;
                setDirection(newDirection);
                setCurrent(index);
              }}
              className={`w-3 h-3 rounded-full transition-colors ${
                index === current ? 'bg-indigo-600' : 'bg-gray-600'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};