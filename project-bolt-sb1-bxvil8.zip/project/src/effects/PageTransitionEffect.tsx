import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const pages = [
  {
    id: 1,
    title: 'Welcome',
    color: 'from-indigo-600 to-purple-600'
  },
  {
    id: 2,
    title: 'About',
    color: 'from-blue-600 to-indigo-600'
  },
  {
    id: 3,
    title: 'Contact',
    color: 'from-purple-600 to-pink-600'
  }
];

export const PageTransitionEffect = () => {
  const [currentPage, setCurrentPage] = useState(0);

  const nextPage = () => {
    setCurrentPage((prev) => (prev + 1) % pages.length);
  };

  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ x: 300, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -300, opacity: 0 }}
          onClick={nextPage}
          className={`w-96 h-96 rounded-2xl bg-gradient-to-br ${pages[currentPage].color} 
            flex items-center justify-center cursor-pointer`}
        >
          <motion.h2
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="text-4xl font-bold text-white"
          >
            {pages[currentPage].title}
          </motion.h2>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};