import React, { useEffect, useRef, useState } from 'react';

export const InteractiveDrawingEffect = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [lastPoint, setLastPoint] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      ctx.lineWidth = 2;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const draw = (e: MouseEvent) => {
      if (!isDrawing || !ctx || !lastPoint) return;

      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      ctx.beginPath();
      ctx.moveTo(lastPoint.x, lastPoint.y);
      ctx.lineTo(x, y);
      
      const gradient = ctx.createLinearGradient(
        lastPoint.x, lastPoint.y, x, y
      );
      gradient.addColorStop(0, '#4F46E5');
      gradient.addColorStop(1, '#9333EA');
      ctx.strokeStyle = gradient;
      
      ctx.stroke();
      setLastPoint({ x, y });
    };

    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mousedown', (e) => {
      setIsDrawing(true);
      const rect = canvas.getBoundingClientRect();
      setLastPoint({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    });
    canvas.addEventListener('mouseup', () => setIsDrawing(false));
    canvas.addEventListener('mouseout', () => setIsDrawing(false));

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      canvas.removeEventListener('mousemove', draw);
    };
  }, [isDrawing, lastPoint]);

  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center">
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-crosshair"
      />
    </div>
  );
};