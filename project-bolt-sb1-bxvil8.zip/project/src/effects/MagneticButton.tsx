import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';

export const MagneticButton = () => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const boundingRef = useRef<DOMRect | null>(null);
  const mouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const button = buttonRef.current;
    if (!button) return;

    const onMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      mouseRef.current = { x: clientX, y: clientY };

      if (!boundingRef.current) {
        boundingRef.current = button.getBoundingClientRect();
      }

      const { left, top, width, height } = boundingRef.current;
      const centerX = left + width / 2;
      const centerY = top + height / 2;

      const deltaX = clientX - centerX;
      const deltaY = clientY - centerY;
      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
      const radius = 400;

      if (distance < radius) {
        const strength = (radius - distance) / radius;
        gsap.to(button, {
          x: deltaX * strength * 0.3,
          y: deltaY * strength * 0.3,
          duration: 0.6,
          ease: 'power2.out'
        });
      } else {
        gsap.to(button, {
          x: 0,
          y: 0,
          duration: 0.6,
          ease: 'power2.out'
        });
      }
    };

    const onMouseLeave = () => {
      gsap.to(button, {
        x: 0,
        y: 0,
        duration: 0.6,
        ease: 'power2.out'
      });
    };

    window.addEventListener('mousemove', onMouseMove);
    button.addEventListener('mouseleave', onMouseLeave);

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      button.removeEventListener('mouseleave', onMouseLeave);
    };
  }, []);

  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center">
      <button
        ref={buttonRef}
        className="px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 
          text-white rounded-lg text-xl font-bold transform hover:scale-105 
          transition-transform duration-200"
      >
        Magnetic Button
      </button>
    </div>
  );
};