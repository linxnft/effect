export interface Effect {
  id: string;
  title: string;
  category: 'framer' | 'gsap' | 'canvas' | 'css';
  description: string;
  preview: string;
}

export interface Category {
  id: 'framer' | 'gsap' | 'canvas' | 'css';
  title: string;
  icon: string;
  description: string;
}