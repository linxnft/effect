import { Effect } from '../types';

export const effects: Effect[] = [
  {
    id: 'parallax-scroll',
    title: 'Parallax Scroll',
    category: 'framer',
    description: 'Smooth parallax scrolling effect with depth layers\n\nPrompt: "Create a parallax scrolling effect using Framer Motion with multiple layers moving at different speeds. Include background image, text overlay, and interactive elements that respond to scroll position."',
    preview: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809'
  },
  {
    id: 'drag-drop',
    title: 'Drag & Drop Gallery',
    category: 'framer',
    description: 'Interactive drag and drop image gallery with smooth animations\n\nPrompt: "Implement a drag and drop gallery using Framer Motion with reordering capabilities, smooth transitions, and scale animations on drag."',
    preview: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb'
  },
  {
    id: 'page-transitions',
    title: 'Page Transitions',
    category: 'framer',
    description: 'Seamless page transition effects\n\nPrompt: "Create smooth page transitions using Framer Motion with shared layout animations, fade effects, and dynamic route changes."',
    preview: 'https://images.unsplash.com/photo-1550859492-d5da9d8e45f3'
  },
  {
    id: '3d-carousel',
    title: '3D Carousel',
    category: 'framer',
    description: 'Interactive 3D carousel with perspective effects\n\nPrompt: "Create an interactive 3D carousel using Framer Motion with perspective transforms, smooth transitions, and gesture controls."',
    preview: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679'
  },
  {
    id: 'floating-cards',
    title: 'Floating Cards',
    category: 'framer',
    description: 'Floating cards with physics-based motion\n\nPrompt: "Create floating cards that respond to cursor movement with realistic physics using Framer Motion springs and drag constraints."',
    preview: 'https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead'
  },
  {
    id: 'morphing-shapes',
    title: 'Morphing Shapes',
    category: 'gsap',
    description: 'Fluid shape morphing animations\n\nPrompt: "Create a shape morphing animation using GSAP that smoothly transitions between different SVG paths with custom easing and timeline controls."',
    preview: 'https://images.unsplash.com/photo-1550859492-d5da9d8e45f3'
  },
  {
    id: 'scroll-trigger',
    title: 'Scroll Trigger Animation',
    category: 'gsap',
    description: 'Elements animate as you scroll\n\nPrompt: "Implement scroll-triggered animations using GSAP ScrollTrigger with elements that fade, scale, and move into view as the user scrolls."',
    preview: 'https://images.unsplash.com/photo-1557672172-298e090bd0f1'
  },
  {
    id: 'text-animation',
    title: 'Text Animation',
    category: 'gsap',
    description: 'Dynamic text reveal animations\n\nPrompt: "Create advanced text animations using GSAP with letter splitting, staggered reveals, and dynamic color changes."',
    preview: 'https://images.unsplash.com/photo-1618004652321-13a63e576b80'
  },
  {
    id: 'magnetic-button',
    title: 'Magnetic Button',
    category: 'gsap',
    description: 'Interactive magnetic button effect\n\nPrompt: "Create a magnetic button effect using GSAP that attracts the cursor and creates smooth, elastic movements."',
    preview: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee'
  },
  {
    id: 'liquid-text',
    title: 'Liquid Text',
    category: 'gsap',
    description: 'Text that morphs like liquid\n\nPrompt: "Create a liquid text effect using GSAP where characters flow and morph with smooth, fluid animations."',
    preview: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4'
  },
  {
    id: 'particle-system',
    title: 'Particle System',
    category: 'canvas',
    description: 'Interactive particle system with physics\n\nPrompt: "Create an interactive particle system using Canvas API with physics simulation, color transitions, and mouse interaction."',
    preview: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986'
  },
  {
    id: 'generative-art',
    title: 'Generative Art',
    category: 'canvas',
    description: 'Dynamic generative artwork\n\nPrompt: "Create generative art using Canvas API with procedural generation, random patterns, and dynamic color palettes."',
    preview: 'https://images.unsplash.com/photo-1550859492-d5da9d8e45f3'
  },
  {
    id: 'interactive-drawing',
    title: 'Interactive Drawing',
    category: 'canvas',
    description: 'Draw with special effects\n\nPrompt: "Implement an interactive drawing system using Canvas API with brush effects, color blending, and particle trails."',
    preview: 'https://images.unsplash.com/photo-1605721911519-3dfeb3be25e7'
  },
  {
    id: 'fluid-simulation',
    title: 'Fluid Simulation',
    category: 'canvas',
    description: 'Interactive fluid dynamics simulation\n\nPrompt: "Create an interactive fluid simulation using Canvas API with realistic physics, color mixing, and mouse interaction."',
    preview: 'https://images.unsplash.com/photo-1604076913837-52ab5629fba9'
  },
  {
    id: 'audio-visualizer',
    title: 'Audio Visualizer',
    category: 'canvas',
    description: 'Dynamic audio visualization\n\nPrompt: "Create a real-time audio visualizer using Canvas API with frequency analysis, dynamic shapes, and color reactions."',
    preview: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745'
  },
  {
    id: 'gradient-wave',
    title: 'Gradient Wave',
    category: 'css',
    description: 'Animated gradient wave effect\n\nPrompt: "Create a smooth gradient wave animation using pure CSS with multiple layers, custom timing, and color transitions."',
    preview: 'https://images.unsplash.com/photo-1557672172-298e090bd0f1'
  },
  {
    id: 'card-flip',
    title: '3D Card Flip',
    category: 'css',
    description: 'Smooth 3D card flip animation\n\nPrompt: "Implement a 3D card flip effect using CSS transforms with smooth transitions and hover interactions."',
    preview: 'https://images.unsplash.com/photo-1553481187-be93c21490a9'
  },
  {
    id: 'loading-spinner',
    title: 'Loading Spinner',
    category: 'css',
    description: 'Creative loading animation\n\nPrompt: "Design a creative loading spinner animation using CSS with multiple elements, color changes, and smooth transitions."',
    preview: 'https://images.unsplash.com/photo-1557672172-298e090bd0f1'
  },
  {
    id: 'glitch-effect',
    title: 'Glitch Effect',
    category: 'css',
    description: 'Dynamic text glitch animation\n\nPrompt: "Create a cyberpunk-style glitch effect using pure CSS with text distortion, color shifts, and random timing."',
    preview: 'https://images.unsplash.com/photo-1542831371-32f555c86880'
  },
  {
    id: 'neon-pulse',
    title: 'Neon Pulse',
    category: 'css',
    description: 'Pulsating neon light effect\n\nPrompt: "Create a neon light effect using pure CSS with realistic glow, color pulsing, and text shadows."',
    preview: 'https://images.unsplash.com/photo-1563089145-599997674d42'
  }
];