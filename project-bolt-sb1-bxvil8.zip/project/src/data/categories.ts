import { Category } from '../types';
import { Sparkles, Box, PenTool, Palette } from 'lucide-react';

export const categories: Category[] = [
  {
    id: 'framer',
    title: 'Framer Motion',
    icon: 'Sparkles',
    description: 'Production-ready animations for React applications'
  },
  {
    id: 'gsap',
    title: 'GSAP',
    icon: 'Box',
    description: 'Professional-grade animation for the modern web'
  },
  {
    id: 'canvas',
    title: 'Canvas',
    icon: 'PenTool',
    description: 'Dynamic, interactive graphics and animations'
  },
  {
    id: 'css',
    title: 'CSS',
    icon: 'Palette',
    description: 'Pure CSS animations and transitions'
  }
];