import React from 'react';
import { motion } from 'framer-motion';
import { Effect } from '../types';

interface EffectCardProps {
  effect: Effect;
  onClick: () => void;
}

export const EffectCard: React.FC<EffectCardProps> = ({ effect, onClick }) => {
  return (
    <motion.div
      layoutId={`effect-${effect.id}`}
      whileHover={{ y: -8 }}
      onClick={onClick}
      className="effect-card cursor-pointer group"
    >
      <div className="aspect-video relative overflow-hidden rounded-t-xl">
        <img
          src={effect.preview}
          alt={effect.title}
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2">{effect.title}</h3>
        <p className="text-gray-600 text-sm">{effect.description}</p>
      </div>
    </motion.div>
  );
};