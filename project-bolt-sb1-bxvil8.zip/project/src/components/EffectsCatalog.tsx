import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CategoryNav } from './CategoryNav';
import { EffectCard } from './EffectCard';
import { EffectViewer } from './EffectViewer';
import { effects } from '../data/effects';
import { Effect } from '../types';

export const EffectsCatalog = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedEffect, setSelectedEffect] = useState<Effect | null>(null);

  const filteredEffects = activeCategory === 'all'
    ? effects
    : effects.filter(effect => effect.category === activeCategory);

  return (
    <section className="py-24 px-4 bg-gray-50" id="explore">
      <div className="container mx-auto">
        <CategoryNav
          activeCategory={activeCategory}
          onSelectCategory={setActiveCategory}
        />
        
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence>
            {filteredEffects.map((effect) => (
              <EffectCard
                key={effect.id}
                effect={effect}
                onClick={() => setSelectedEffect(effect)}
              />
            ))}
          </AnimatePresence>
        </motion.div>

        <EffectViewer
          effect={selectedEffect}
          onClose={() => setSelectedEffect(null)}
        />
      </div>
    </section>
  );
};