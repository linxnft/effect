import React from 'react';
import { motion } from 'framer-motion';
import { categories } from '../data/categories';
import { Sparkles, Box, PenTool, Palette } from 'lucide-react';

const iconMap = {
  Sparkles,
  Box,
  PenTool,
  Palette,
};

interface CategoryNavProps {
  activeCategory: string;
  onSelectCategory: (category: string) => void;
}

export const CategoryNav: React.FC<CategoryNavProps> = ({ activeCategory, onSelectCategory }) => {
  return (
    <nav className="flex flex-wrap justify-center gap-4 mb-12">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => onSelectCategory('all')}
        className={`px-4 py-2 rounded-lg ${
          activeCategory === 'all'
            ? 'bg-indigo-600 text-white'
            : 'bg-white text-gray-600 hover:bg-gray-50'
        }`}
      >
        All Effects
      </motion.button>
      {categories.map((category) => {
        const Icon = iconMap[category.icon as keyof typeof iconMap];
        return (
          <motion.button
            key={category.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelectCategory(category.id)}
            className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
              activeCategory === category.id
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Icon className="w-4 h-4" />
            {category.title}
          </motion.button>
        );
      })}
    </nav>
  );
};