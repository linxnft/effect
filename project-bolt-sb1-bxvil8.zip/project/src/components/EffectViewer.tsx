import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Effect } from '../types';
import { ParallaxEffect } from '../effects/ParallaxEffect';
import { DragDropEffect } from '../effects/DragDropEffect';
import { PageTransitionEffect } from '../effects/PageTransitionEffect';
import { ThreeDCarousel } from '../effects/3DCarousel';
import { FloatingCards } from '../effects/FloatingCards';
import { MorphingEffect } from '../effects/MorphingEffect';
import { TextAnimationEffect } from '../effects/TextAnimationEffect';
import { MagneticButton } from '../effects/MagneticButton';
import { LiquidText } from '../effects/LiquidText';
import { ParticleEffect } from '../effects/ParticleEffect';
import { GenerativeArtEffect } from '../effects/GenerativeArtEffect';
import { InteractiveDrawingEffect } from '../effects/InteractiveDrawingEffect';
import { FluidSimulation } from '../effects/FluidSimulation';
import { AudioVisualizer } from '../effects/AudioVisualizer';
import { GradientWaveEffect } from '../effects/GradientWaveEffect';
import { CardFlipEffect } from '../effects/CardFlipEffect';
import { LoadingSpinnerEffect } from '../effects/LoadingSpinnerEffect';
import { GlitchEffect } from '../effects/GlitchEffect';
import { NeonPulse } from '../effects/NeonPulse';

interface EffectViewerProps {
  effect: Effect | null;
  onClose: () => void;
}

export const EffectViewer: React.FC<EffectViewerProps> = ({ effect, onClose }) => {
  if (!effect) return null;

  const getEffectComponent = () => {
    switch (effect.id) {
      case 'parallax-scroll':
        return <ParallaxEffect />;
      case 'drag-drop':
        return <DragDropEffect />;
      case 'page-transitions':
        return <PageTransitionEffect />;
      case '3d-carousel':
        return <ThreeDCarousel />;
      case 'floating-cards':
        return <FloatingCards />;
      case 'morphing-shapes':
        return <MorphingEffect />;
      case 'text-animation':
        return <TextAnimationEffect />;
      case 'magnetic-button':
        return <MagneticButton />;
      case 'liquid-text':
        return <LiquidText />;
      case 'particle-system':
        return <ParticleEffect />;
      case 'generative-art':
        return <GenerativeArtEffect />;
      case 'interactive-drawing':
        return <InteractiveDrawingEffect />;
      case 'fluid-simulation':
        return <FluidSimulation />;
      case 'audio-visualizer':
        return <AudioVisualizer />;
      case 'gradient-wave':
        return <GradientWaveEffect />;
      case 'card-flip':
        return <CardFlipEffect />;
      case 'loading-spinner':
        return <LoadingSpinnerEffect />;
      case 'glitch-effect':
        return <GlitchEffect />;
      case 'neon-pulse':
        return <NeonPulse />;
      default:
        return null;
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
      >
        <div className="absolute inset-0 overflow-auto">
          <button
            onClick={onClose}
            className="fixed top-4 right-4 p-2 bg-white/90 rounded-full hover:bg-white transition-colors z-10"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="p-4">
            <div className="max-w-4xl mx-auto bg-white rounded-xl p-6 mb-4">
              <h2 className="text-2xl font-bold mb-2">{effect.title}</h2>
              <pre className="whitespace-pre-wrap text-sm text-gray-600 font-mono bg-gray-50 p-4 rounded-lg">
                {effect.description}
              </pre>
            </div>
          </div>
          
          {getEffectComponent()}
        </div>
      </motion.div>
    </AnimatePresence>
  );
};